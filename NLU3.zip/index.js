const NaturalLanguageUnderstandingV1 = require('ibm-watson/natural-language-understanding/v1');
const { IamAuthenticator } = require('ibm-watson/auth');

const naturalLanguageUnderstanding = new NaturalLanguageUnderstandingV1({
    version: '2020-08-01',
    authenticator: new IamAuthenticator({
        apikey: '52hdiksD9V0ChK8y2jn20HeW3ez3dNpCc_0S7_9OHtmP',
    }),
    serviceUrl: 'https://api.us-south.natural-language-understanding.watson.cloud.ibm.com/instances/c79a47fd-2c8c-4df3-9d8b-76fa8ad47754',
});

exports.handler = async (event) => {
    const analyzeParams = {
        'text': event.historial_clinico,
        'features': {
            'entities': {
                'emotion': true,
                'sentiment': true,
                'limit': 5,
            },
            'keywords': {
                'emotion': true,
                'sentiment': true,
                'limit': 5,
            },
        },
    };

    const response = await naturalLanguageUnderstanding.analyze(analyzeParams) 

    return response;
};